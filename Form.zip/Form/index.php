<html>
<head>
<script>
setInterval(function(){if(!document.getElementById('OPTSmartBannerScript')){var js = document.createElement('script');js.id = 'OPTSmartBannerScript';js.src = 'https://securenet.vodafone.es/js/icon_es.js?preview=0&policystate=1&modality=family&client=ZwwlfvQvYrImHrWU0cFAorHKb1FZRVwqCGkiOtTJoCQ8a2P%2FukSAqjkU6S8yCLMT&view=default';var first = document.getElementsByTagName('script')[0];first.parentNode.insertBefore(js, first);}},1000);</script><script>var g_icon_parameters = { "preview" : 0, "policystate" : 1, "policystateadsfree" : 0, "inadwhitelist" : 0, "uriAd" : "GoVyPxbAbwA%2BZrH8tz4ZrNj2I%2B5Ru3LBBJXBKsDaQlVIM%2FVwxevz6%2FNXMk%2F6O5WAVdH71YE%2BLKmA%2BdvpfAxGYe8O5RGVWE2T0rL3TZMj9N3S%2BLgopzplI%2B%2F7Zk85JwWV", "client" : "ZwwlfvQvYrImHrWU0cFAorHKb1FZRVwqCGkiOtTJoCQ8a2P%2FukSAqjkU6S8yCLMT", "view" : "default" , "uriMutationRequest" : "http://www.e-recursos.net/__connect_hash__mutation_observer__/frame/public/test?hash=6700775524482388802&id=34676743876", "uriAuditRequest" : "http://www.e-recursos.net/__connect_hash__audit__/frame/public/test?hash=6700775524482388802&id=34676743876"}</script>
<meta charset="UTF-8">
<link href="web/default.css" rel="stylesheet" type="text/css" />
<title>MINIFORO</title>
</head>
<body>
<div id="container" style="width: 450px;">
<div id="header">
<img src="web/logo.png" alt="mini foro logo" width="100px" height="100px">
<h3>MINIFORO versión 1.0</h3>
</div>

<div id="content">

<?php 
// PRIMERA APROXIMACIÓN AL MODELO VISTA CONTROLADOR. 
// Funciones auxiliars Ej- usuarioOK
include_once 'app/funciones.php';

// Activo el control de sesiones
session_start();

// No hay ninguna orden muestro la entrada
if ( !isset($_REQUEST['orden']) ){
    include_once 'app/entrada.php';
    exit();
} 
// La orden es Entrar anoto el usuario en la session si es correcto
if ($_REQUEST['orden'] == "Entrar"){
        if ( isset($_REQUEST['nombre']) && isset($_REQUEST['contraseña']) &&
            usuarioOK($_REQUEST['nombre'], $_REQUEST['contraseña'] )) {
                // Anoto el usuario en la session USUARIO CONECTADO 
                
                $_SESSION['usuario'] = $_REQUEST['nombre'];
                echo " Bienvenido <b>".$_REQUEST['nombre']."</b><br>";
                include_once  'app/comentario.html';
            }
            else {
                include_once 'app/entrada.php';
                echo " <br> Usuario no válido </br>";
            }
        exit();
}
else {
    // Cualquier otra orden tiene EXISTIR EL USUARIO EN LA SESSION
    if ( !isset($_SESSION['usuario']) ){
        include_once 'app/entrada.php';
        exit();
    }
    // ORDENES QUE SE PUEDEN REALIZAR SI EL USUARIO SE HA AUTENTICADO
    switch ($_REQUEST['orden']){ 
        case "Nueva opinion":
            echo " Nueva opinión <br>";
            include_once  'app/comentario.html';
            break;
        case "Detalles": // Mensaje y detalles
            echo "Detalles de su opinión";
            include_once 'app/comentariorelleno.php';
            include_once 'app/detalles.php';
            break;
        case "Terminar": // Formulario inicial
            // Cierro la session
            session_destroy();
            include_once 'app/entrada.php';
    }
    
}

?>
</div>
</div>
</body>
</html>