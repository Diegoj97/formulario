<?php


include_once 'app/funciones.php';


echo "DETALLES";


$dato = longitud($_REQUEST["comentario"]);

echo " <br> la longitud del comentario es de  $dato";

$letrarep =numero($_REQUEST["comentario"]);

echo " <br>  la letra mas repetida es:   $letrarep";


$palabra = palabrarep($_REQUEST["comentario"]);

echo " <br>  la palabra mas repetida es   $palabra";


?>