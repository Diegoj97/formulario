



<?php

$asunto = $_REQUEST["asunto"];
$comentario = $_REQUEST["comentario"];



?>

<form name='entrada' method="GET">
  
    
<p>asunto <br> <textarea name="asunto" id="" cols="10" rows="1"> <?php echo $asunto ?> </textarea></p>

  <p>comentario <br> <textarea name="comentario" id="" cols="30" rows="10"> <?php echo $comentario ?> </textarea></p>

  <input type="submit" name="orden" value="Detalles">

  <input type="submit" name="orden" value="Nueva opinion">

  <input type="submit" name="orden" value="Terminar">


</form>




