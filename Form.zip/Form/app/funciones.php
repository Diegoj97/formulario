<?php

function usuarioOK($nombre , $contraseña){

if((strlen($nombre) >= 8 ) && ($contraseña == strrev($nombre))){

return true;

}return false;

}

//muestra la longitud de nuestro comentario
function longitud ($comentario){

    $largo = strlen($comentario);

        return $largo;
}

//muestra la letra mas repetida
function numero ($comentario){



    $max = 0;
    $palabra = null;
    $palabrarepetida = null;


    for($i=0 ; $i < strlen($comentario) ; $i++){

        $palabra = $comentario[$i];

        if($palabra != " " && substr_count($comentario, $palabra)>$max){

                $max = substr_count($comentario,$palabra);
                $palabrarepetida =$palabra;


        }


    }return $palabrarepetida;

  
}
//muestra la palabra mas repetida
function palabrarep ($comentario){



    $max = 0;
    $palabra = null;
    $palabrarepetida = null;


    for($i=0 ; $i < strlen($comentario) ; $i++){

        if($comentario[$i] != " " && $comentario[$i] != ","  ){

            $palabra = $palabra.$comentario[$i];


        }else{

                if(substr_count($comentario, $palabra)>$max){

            $max = substr_count($comentario,$palabra);
            $palabrarepetida = $palabra;

                }

        }


    }return $palabrarepetida;

  
}



?>